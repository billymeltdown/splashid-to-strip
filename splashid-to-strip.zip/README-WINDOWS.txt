On Windows, if you don't have Ruby installed (if you don't know, then chances are you don't), you'll need to install it. 

Get the RubyInstaller for Windows here: (I used version 1.9.2 p290)
http://rubyinstaller.org/downloads/

Run the installer once it finishes downloading, and in the installer options, make sure you check:
'Associate .rb and .rbw files with this Ruby installation'

Download the splashid-to-strip.zip project and extract the contents into a folder named SplashID on your Desktop.

Export your SplashID data, save your SplashID Export.vid file to the SplashID folder on your Desktop as well.

At this point, convert.rb and 'SplashID Export.vid' should be in the same folder. 

Once that's the case, double-click convert.rb to launch the conversion! 

When the installer finishes, you will have a file 'strip-import.csv' in your SplashID folder.
